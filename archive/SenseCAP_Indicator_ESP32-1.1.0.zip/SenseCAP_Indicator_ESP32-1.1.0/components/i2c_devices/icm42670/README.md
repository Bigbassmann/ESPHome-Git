## ICM-42670-P

The [ICM-42670-P](https://3cfeqx1hf82y3xcoull08ihx-wpengine.netdna-ssl.com/wp-content/uploads/2021/07/DS-000451-ICM-42670-P-v1.0.pdf) is a 6-axis MEMS Motion Tracking device that combines a 3‑axis gyroscope and a 3‑axis accelerometer.

**ICM-42607-P** labled in schematic is an used name of **ICM-42670-P**, the two chips are fully pin-to-pin compatible.